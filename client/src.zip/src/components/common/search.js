import './search.css'
const Search=()=>{
    return(
        <div className='search-img'>
            <input className='search-tag' type='search'/>
        </div>
    )
}

export default Search