import "./foot.css";
const Footer = ()=>{
    return(
        <>
        <div className="footer-main">
            <span className="footer-year">2021</span>
            <span className="footer-symbol">©</span>
            <span className="footer-laundry">Laundry</span>
        </div>
        </>
    )
}

export default Footer;