// import home from "../assests/home-run(1).svg"
import "./navbar.css"
const NavBar=()=>{
    return (
        <>
            <div className="nav-main">
                <div className="nav-home"></div>
                <div className="nav-more"></div>
                <div className="nav-div">
                <span className="nav-list"></span>
                </div>
                
            </div>
        </>
    )
}

export default NavBar;